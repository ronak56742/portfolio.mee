
  # Data Analytics Portfolio Website

  This is a code bundle for Data Analytics Portfolio Website. The original project is available at https://www.figma.com/design/wTJA5tNfiz6gDcwx90TxVB/Data-Analytics-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  